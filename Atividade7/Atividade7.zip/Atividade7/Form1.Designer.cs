﻿
namespace Atividade7
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fraseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.númeroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.palíndromoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salárioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fraseToolStripMenuItem,
            this.númeroToolStripMenuItem,
            this.palíndromoToolStripMenuItem,
            this.salárioToolStripMenuItem,
            this.sairToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fraseToolStripMenuItem
            // 
            this.fraseToolStripMenuItem.Name = "fraseToolStripMenuItem";
            this.fraseToolStripMenuItem.Size = new System.Drawing.Size(46, 20);
            this.fraseToolStripMenuItem.Text = "Frase";
            this.fraseToolStripMenuItem.Click += new System.EventHandler(this.fraseToolStripMenuItem_Click);
            // 
            // númeroToolStripMenuItem
            // 
            this.númeroToolStripMenuItem.Name = "númeroToolStripMenuItem";
            this.númeroToolStripMenuItem.Size = new System.Drawing.Size(63, 20);
            this.númeroToolStripMenuItem.Text = "Número";
            this.númeroToolStripMenuItem.Click += new System.EventHandler(this.númeroToolStripMenuItem_Click);
            // 
            // palíndromoToolStripMenuItem
            // 
            this.palíndromoToolStripMenuItem.Name = "palíndromoToolStripMenuItem";
            this.palíndromoToolStripMenuItem.Size = new System.Drawing.Size(81, 20);
            this.palíndromoToolStripMenuItem.Text = "Palíndromo";
            this.palíndromoToolStripMenuItem.Click += new System.EventHandler(this.palíndromoToolStripMenuItem_Click);
            // 
            // salárioToolStripMenuItem
            // 
            this.salárioToolStripMenuItem.Name = "salárioToolStripMenuItem";
            this.salárioToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.salárioToolStripMenuItem.Text = "Salário";
            this.salárioToolStripMenuItem.Click += new System.EventHandler(this.salárioToolStripMenuItem_Click);
            // 
            // sairToolStripMenuItem
            // 
            this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            this.sairToolStripMenuItem.Size = new System.Drawing.Size(38, 20);
            this.sairToolStripMenuItem.Text = "Sair";
            this.sairToolStripMenuItem.Click += new System.EventHandler(this.sairToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fraseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem númeroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem palíndromoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salárioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sairToolStripMenuItem;
    }
}

