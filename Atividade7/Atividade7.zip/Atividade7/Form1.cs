﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void fraseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fmrFrase objFrmFrase = new fmrFrase();
            objFrmFrase.MdiParent = this;
            objFrmFrase.WindowState = FormWindowState.Maximized;
            objFrmFrase.Show();
        }

        private void númeroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fmrNumero objFrmNumero = new fmrNumero();
            objFrmNumero.MdiParent = this;
            objFrmNumero.WindowState = FormWindowState.Maximized;
            objFrmNumero.Show();
        }

        private void palíndromoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fmrPalindromo objFrmPalindromo = new fmrPalindromo();
            objFrmPalindromo.MdiParent = this;
            objFrmPalindromo.WindowState = FormWindowState.Maximized;
            objFrmPalindromo.Show();
        }

        private void salárioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fmrSalario objFrmSalario = new fmrSalario();
            objFrmSalario.MdiParent = this;
            objFrmSalario.WindowState = FormWindowState.Maximized;
            objFrmSalario.Show();
        }
    }
}
