﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade7
{
    public partial class fmrFrase : Form
    {
        public fmrFrase()
        {
            InitializeComponent();
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            int quantidade = 0;

            foreach (char item in rchTexto.Text)
            {
                if (char.IsWhiteSpace(item))
                    quantidade++;
            }
            MessageBox.Show(quantidade.ToString());
        }

        private void btnR_Click(object sender, EventArgs e)
        {
            int quantidade = 0;

            foreach (char item in rchTexto.Text)
            {
                if (char.ToUpper(item) == 'R')
                    quantidade++;
            }
            MessageBox.Show(quantidade.ToString());
        }

        private void btnPares_Click(object sender, EventArgs e)
        {
            int quantidade = 0;

            for (int letra = 0; letra < rchTexto.TextLength - 1; letra++)
            {
                if (rchTexto.Text[letra] == rchTexto.Text[letra + 1])
                {
                    quantidade++;
                }
            }
            MessageBox.Show(quantidade.ToString());
        }
    }
}
